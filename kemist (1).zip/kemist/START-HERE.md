# Kemist v2: start here

This zip is the whole project. Copy it over your project folder but KEEP your own `.env`, `.git` and `node_modules`, then check `git diff` before committing.

## 1. Install and test
```
npm install
npm test            # 34+ tests, no internet needed
npm start           # http://localhost:3000 (demo data if Supabase is not set)
```

## 2. Database (Supabase SQL Editor). Run these once, in order
`supabase/002_clinical.sql`, `003_serpapi.sql`, `004_alerts.sql`, `005_news.sql`
(`schema.sql` already contains everything for a brand-new project.)

## 3. New `.env` variables (see `.env.example`)
`GROQ_API_KEY` (AI chat), `SERPAPI_API_KEY` (map listings + news), optional `GEOAPIFY_API_KEY`, `MAP_TILE_URL`,
`OPENFDA_API_KEY`, and multi-key lists `SERPAPI_API_KEYS`, `APIFY_TOKENS`, `GROQ_API_KEYS`.
Use keys you are entitled to. Do not open extra free accounts to get around limits.

## 4. Fill the data (all support --dry first)
| What | Command |
|---|---|
| NAFDAC registrations | `npm run sync:drugs` |
| US label text (library + chat) | `npm run sync:clinical -- --top 50` |
| NAFDAC alerts | `npm run import:alerts -- --wp --dry` (if it works, drop --dry) |
| Health news | `npm run import:news -- --rotate 4` |
| Pharmacies via Google Maps (SerpApi) | `npm run import:serpapi -- --city ibadan --queries pharmacy --max-calls 10` |
| Pharmacies via OpenStreetMap | `npm run prefill:facilities -- --city lagos` |

## 5. What was NOT tested against the real services
Supabase with migrations 003-005, Groq, SerpApi (maps and news), NAFDAC's website feed, openFDA, Overpass.
First run of each: use --dry, then a small real run, and read the output.

## 6. Not built yet
WHO/FDA/EMA direct feeds, admin screens, pharmacy accounts and claiming listings, price data.
