# Kemist

Check a medicine's NAFDAC registration and find pharmacies, clinics and hospitals near you (Nigeria).
Plain HTML/CSS/JS PWA + Node.js/Express API + Supabase (Postgres). AI features come later.

## Run it in 2 minutes (demo mode)
```
npm install
npm start          # http://localhost:3000
```
With no Supabase keys the app runs on 10 sample records (clearly labelled "Demo data"). The map works in demo
mode too: nearby places are pulled live from OpenStreetMap and kept in memory.

## Go live with your own database
1. Create a Supabase project. SQL Editor > paste `supabase/schema.sql` > Run.
2. `cp .env.example .env` and fill `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` (Project Settings > API).
   The service-role key is server-side only. Never put it in `public/` or commit `.env`.
3. Load NAFDAC data (see below), then `npm start`.

## Load NAFDAC data (Apify Greenbook actor)
1. In `.env` set `APIFY_TOKEN`, `APIFY_ACTOR_ID` (format `username~actor-name`, from the actor page) and a small
   `APIFY_INPUT`, e.g. `{"maxItems":100}`. Check the actor's Input tab for its real field names.
2. **Dry run first:** `npm run sync:drugs -- --dry` prints the mapped rows next to the raw record.
   If a field is wrong or empty, adjust the key lists at the top of `src/lib/nafdac.js`.
3. Real import: `npm run sync:drugs` (or `--dataset <id>` / `--file export.json`). Raise `maxItems` once it looks right.
4. `.github/workflows/sync-nafdac.yml` re-syncs weekly. Add the 4 secrets in GitHub.

Every import keeps the raw source record (`source_records`) and an import history (`sync_logs`).

## How it works
- **Check:** `GET /api/drugs?q=` (name, ingredient, company, NRN, typo-tolerant), `GET /api/drugs/verify?nrn=`,
  `GET /api/drugs/:id`, `GET /api/drugs/:id/similar` (other brands, same ingredient).
- **Map:** `GET /api/facilities/nearby?lat&lng&radius&types`. First visit to an area pulls pharmacies, hospitals,
  clinics and labs from OpenStreetMap once (~5 km grid cell), saves them in `facilities`, and serves everyone from
  your database after that. Max radius 5 km.
- **Report:** `POST /api/reports` (rate-limited, honeypot) -> `reports` table. Review them in the Supabase dashboard.
- NRN is **not** unique in the schema: records are keyed by the source's own ID, and a number shared by several
  records shows all of them.

## Safety rules built in (keep them)
- A registration match never says "genuine". Fake packs can copy real numbers. The wording lives in
  `src/routes/drugs.js` and the UI.
- "Not found" says "not in our copy", and points to NAFDAC's Greenbook.
- Facility data is from OpenStreetMap and can be wrong. Nothing is marked verified until a human checks it
  (`facilities.is_verified`).

## Before you launch publicly
- Confirm NAFDAC's terms for storing and republishing Greenbook data (the Apify actor is community-made).
- Confirm the emergency number (112 is used in `public/js/app.js`) and NAFDAC's current pack-verification channel.
- OpenStreetMap's public tile server is for light use. For real traffic use a tile provider (MapTiler, Stadia, etc.).
- Self-host Leaflet/fonts if you need SRI or fewer third parties. Deploy over HTTPS (geolocation needs it).
- Add an admin screen for reports, tests, and monitoring. Review Nigeria Data Protection Act duties for reports.

## Next phases
Pharmacy/clinic accounts and claiming listings, drug images, price observations, then AI (RAG over your own data with Groq).
The matching/clinical-source design (DailyMed/openFDA, separate source records, reviewed matches) is a good model
for that stage.
