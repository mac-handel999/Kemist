'use strict';
/* Medicines library: US drug-label information (openFDA) by active ingredient, with the Nigerian products that contain it. */
(() => {
  const { h, put, api, icon, fmtDate, loading } = window.Kemist;
  const SECTIONS = [['indications', 'What it is used for'], ['contraindications', 'Who should not use it'], ['warnings', 'Warnings and precautions'], ['adverse_reactions', 'Possible side effects'], ['interactions', 'Interactions with other medicines']];
  const title = (k) => String(k).replace(/\b\w/g, (c) => c.toUpperCase());

  async function Index(params) {
    document.title = 'Medicines library · Kemist';
    const list = h('div', { class: 'results', 'aria-live': 'polite' });
    const input = h('input', { type: 'search', placeholder: 'Search an ingredient, e.g. paracetamol', maxlength: '60', value: params.get('q') || '', 'aria-label': 'Search the library' });
    let seq = 0;
    async function load() {
      const mine = ++seq;
      put(list, loading('Loading'));
      try {
        const r = await api(`/api/clinical/ingredients?q=${encodeURIComponent(input.value.trim())}`);
        if (mine !== seq) return;
        put(list, r.data.length ? r.data.map((x) => h('a', { class: 'result link', href: `#/library/${encodeURIComponent(x.ingredient_key)}` },
          h('div', { class: 'result-top' }, h('h3', null, title(x.label || x.ingredient_key)), h('span', { class: 'pill info' }, 'US label')),
          h('span', { class: 'meta' }, [x.latest && `label dated ${fmtDate(x.latest)}`, x.source].filter(Boolean).join(' · ')))) : h('div', { class: 'empty' }, 'No ingredient found yet. The library grows as label information is imported.'));
      } catch (e) { if (mine === seq) put(list, h('div', { class: 'msg err', role: 'alert' }, e.message)); }
    }
    input.addEventListener('input', () => { clearTimeout(input._t); input._t = setTimeout(load, 300); });
    put(window.Kemist.viewEl(), h('div', { class: 'page' },
      h('div', { class: 'stack' }, h('h1', null, 'Medicines library'),
        h('p', { class: 'lead' }, 'What a medicine is used for, and its warnings, from US drug labels. Each page also lists the Nigerian products registered with that ingredient.')),
      h('div', { class: 'callout' }, h('strong', null, 'US label information'),
        h('p', null, 'This text comes from United States labels. It is not the NAFDAC leaflet for any Nigerian product, and it is not medical advice. Ask a pharmacist or doctor.')),
      input, list));
    load();
  }

  async function Detail(key) {
    const page = h('div', { class: 'page' }, h('a', { class: 'back', href: '#/library' }, icon('back'), 'Back to the library'), loading('Loading'));
    put(window.Kemist.viewEl(), page);
    try {
      const r = await api(`/api/clinical/ingredient/${encodeURIComponent(key)}`);
      document.title = `${title(r.ingredient_key)} · Medicines library`;
      const label = r.labels[0];
      put(page,
        h('a', { class: 'back', href: '#/library' }, icon('back'), 'Back to the library'),
        h('h1', null, title(r.ingredient_key)),
        h('div', { class: 'callout' }, h('strong', null, 'From a US label, not from NAFDAC'), h('p', null, r.note)),
        h('p', { class: 'hint' }, [label.title, label.effective_date && `label dated ${fmtDate(label.effective_date)}`].filter(Boolean).join(' · '), ' · ',
          h('a', { href: label.source_url, target: '_blank', rel: 'noopener noreferrer' }, `Source: ${label.source}`)),
        SECTIONS.filter(([k]) => label.sections[k]).map(([k, name]) => h('details', { class: 'callout', open: k === 'indications' },
          h('summary', null, name), h('p', { style: 'white-space:pre-line;overflow-wrap:anywhere' }, label.sections[k]))),
        h('div', { class: 'stack' },
          h('div', { class: 'section-title' }, h('h2', null, 'Registered in Nigeria'), h('span', { class: 'count' }, `${r.products.length} product${r.products.length === 1 ? '' : 's'}`)),
          r.products.length ? h('div', { class: 'results' }, r.products.map(window.Kemist.medicineCard)) : h('div', { class: 'empty' }, 'No single-ingredient product with this name was found in the NAFDAC records Kemist holds.')),
        h('div', { class: 'actions' }, h('a', { class: 'btn', href: `#/ask?${new URLSearchParams({ q: `What is ${title(r.ingredient_key)} used for?` })}` }, icon('chat'), 'Ask Kemist about this')));
    } catch (e) {
      put(page, h('a', { class: 'back', href: '#/library' }, icon('back'), 'Back to the library'), h('div', { class: 'msg err', role: 'alert' }, e.message));
    }
  }

  window.Kemist.views.library = (parts, params) => (parts[1] ? Detail(decodeURIComponent(parts[1])) : Index(params));
})();
