'use strict';
/* Updates: NAFDAC safety alerts (official notices) and health news headlines. */
(() => {
  const { h, put, api, icon, ICON, fmtDate, timeAgo, loading } = window.Kemist;

  const TYPE_LABEL = { counterfeit: 'Counterfeit', recall: 'Recall', substandard: 'Substandard', unregistered: 'Unregistered or banned', notice: 'Notice' };
  const TYPE_CLASS = { counterfeit: 'bad', recall: 'warn', substandard: 'warn', unregistered: 'warn', notice: 'info' };
  const CATEGORY_LABEL = { nigeria: 'Nigeria health', pharmacy: 'Pharmacy and medicines', safety: 'Medicine safety', outbreak: 'Outbreaks', world: 'World health' };

  function alertCard(a) {
    return h('article', { class: `alert-card ${TYPE_CLASS[a.alert_type] || 'info'}` },
      h('div', { class: 'alert-top' },
        h('span', { class: `pill ${TYPE_CLASS[a.alert_type] || 'info'}` }, icon(a.alert_type === 'notice' ? 'info' : 'alert'), TYPE_LABEL[a.alert_type] || 'Notice'),
        h('span', { class: 'meta' }, [a.alert_no && `No. ${a.alert_no}`, a.published_at && fmtDate(a.published_at)].filter(Boolean).join(' · '))),
      h('h3', null, a.title),
      a.summary && h('p', { class: 'meta' }, a.summary),
      (a.nrns || []).length > 0 && h('div', { class: 'chips' }, h('span', { class: 'hint' }, 'Numbers mentioned:'),
        a.nrns.map((n) => h('a', { class: 'nrn-tag', href: `#/?q=${encodeURIComponent(n)}` }, n))),
      h('a', { class: 'ext', href: a.source_url, target: '_blank', rel: 'noopener noreferrer' }, `Read the ${a.source || 'NAFDAC'} notice`, icon('external')));
  }

  function newsCard(n) {
    return h('article', { class: 'news-card' },
      h('span', { class: 'meta' }, [CATEGORY_LABEL[n.category], n.publisher, timeAgo(n.published_at)].filter(Boolean).join(' · ')),
      h('h3', null, h('a', { href: n.url, target: '_blank', rel: 'noopener noreferrer' }, n.title)),
      n.snippet && h('p', { class: 'meta' }, n.snippet));
  }
  window.Kemist.alertCard = alertCard;
  window.Kemist.newsCard = newsCard;

  function tabs(active) {
    return h('div', { class: 'tabs', role: 'tablist' },
      h('a', { role: 'tab', class: 'tab', href: '#/updates', 'aria-selected': String(active === 'alerts') }, 'Safety alerts'),
      h('a', { role: 'tab', class: 'tab', href: '#/updates/news', 'aria-selected': String(active === 'news') }, 'Health news'));
  }

  function AlertsTab(body) {
    let type = null, q = '', seq = 0;
    const list = h('div', { class: 'results', 'aria-live': 'polite' });
    const input = h('input', { type: 'search', placeholder: 'Search alerts, e.g. artemether or 04-6433', maxlength: '80', 'aria-label': 'Search alerts' });
    const chipsEl = h('div', { class: 'chips' });

    async function load() {
      const mine = ++seq;
      put(list, loading('Loading alerts'));
      try {
        const qs = new URLSearchParams({ limit: '40' }); if (type) qs.set('type', type); if (q) qs.set('q', q);
        const r = await api(`/api/alerts?${qs}`);
        if (mine !== seq) return;
        put(list, r.data.length ? r.data.map(alertCard) : h('div', { class: 'empty' }, 'No alerts match. Alerts appear here once they have been imported from NAFDAC.'));
      } catch (e) { if (mine === seq) put(list, h('div', { class: 'msg err', role: 'alert' }, e.message)); }
    }
    function drawChips() {
      put(chipsEl, [[null, 'All'], ...Object.entries(TYPE_LABEL)].map(([k, label]) => h('button', { class: 'chip', type: 'button', 'aria-pressed': String(type === k), onclick: () => { type = k; drawChips(); load(); } }, label)));
    }
    input.addEventListener('input', () => { clearTimeout(input._t); input._t = setTimeout(() => { q = input.value.trim(); load(); }, 350); });

    put(body, h('div', { class: 'callout' }, h('strong', null, 'Official notices, not a full blacklist'),
      h('p', null, 'These are alerts that NAFDAC has published. They do not list every fake medicine in circulation. Always read the original notice. If a medicine looks wrong, report it.')),
      input, chipsEl, list,
      h('div', { class: 'actions' }, h('a', { class: 'btn', href: '#/report' }, 'Report a suspicious medicine')));
    drawChips(); load();
  }

  function NewsTab(body) {
    let category = null, seq = 0;
    const list = h('div', { class: 'results', 'aria-live': 'polite' });
    const stamp = h('p', { class: 'hint' });
    const chipsEl = h('div', { class: 'chips' });

    async function load() {
      const mine = ++seq;
      put(list, loading('Loading news'));
      try {
        const qs = new URLSearchParams({ limit: '30' }); if (category) qs.set('category', category);
        const r = await api(`/api/news?${qs}`);
        if (mine !== seq) return;
        stamp.textContent = r.last_updated ? `Last updated ${timeAgo(r.last_updated)}. ${r.note}` : r.note;
        put(list, r.data.length ? r.data.map(newsCard) : h('div', { class: 'empty' }, 'No headlines yet. They appear here once the news collection has run.'));
      } catch (e) { if (mine === seq) put(list, h('div', { class: 'msg err', role: 'alert' }, e.message)); }
    }
    function drawChips() {
      put(chipsEl, [[null, 'All'], ...Object.entries(CATEGORY_LABEL)].map(([k, label]) => h('button', { class: 'chip', type: 'button', 'aria-pressed': String(category === k), onclick: () => { category = k; drawChips(); load(); } }, label)));
    }
    put(body, chipsEl, stamp, list);
    drawChips(); load();
  }

  function UpdatesView(parts) {
    const onNews = parts[0] === 'news' || parts[1] === 'news';
    document.title = `${onNews ? 'Health news' : 'Safety alerts'} · Kemist`;
    const body = h('div', { class: 'stack' });
    put(window.Kemist.viewEl(), h('div', { class: 'page' },
      h('div', { class: 'stack' }, h('h1', null, 'Updates'),
        h('p', { class: 'lead' }, 'Official medicine safety notices from NAFDAC, and health headlines from Nigeria and the world.')),
      tabs(onNews ? 'news' : 'alerts'), body));
    (onNews ? NewsTab : AlertsTab)(body);
  }

  for (const name of ['updates', 'alerts', 'news']) window.Kemist.views[name] = UpdatesView;
})();
