'use strict';
/* Kemist illustrations: plain SVG strings in the brand colours (green, ink, marker yellow). Decorative only: callers mark them aria-hidden. */
(() => {
  const C = { g: '#00844F', gd: '#005C38', tint: '#E0F3E8', mint: '#BFE6D0', ink: '#0F2B25', y: '#FFE566', w: '#FFFFFF', grey: '#D5DFDA' };
  const S = `stroke="${C.ink}" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"`;

  const capsule = (x, y, rot, left, right, len = 66, w = 26) => {
    const r = w / 2, hl = len / 2 - r;
    return `<g transform="translate(${x} ${y}) rotate(${rot})">
      <path d="M0 ${-r} H${-hl} A${r} ${r} 0 0 0 ${-hl} ${r} H0 Z" fill="${left}"/>
      <path d="M0 ${-r} H${hl} A${r} ${r} 0 0 1 ${hl} ${r} H0 Z" fill="${right}"/>
      <rect x="${-len / 2}" y="${-r}" width="${len}" height="${w}" rx="${r}" fill="none" ${S}/>
      <path d="M0 ${-r} V${r}" ${S}/>
    </g>`;
  };
  const plus = (x, y, s, c = C.g) => `<path d="M${x - s} ${y}H${x + s}M${x} ${y - s}V${y + s}" stroke="${c}" stroke-width="5" stroke-linecap="round"/>`;
  const check = (x, y, s, c) => `<path d="M${x - s} ${y}l${s * 0.8} ${s * 0.8}l${s * 1.4} ${-s * 1.6}" fill="none" stroke="${c}" stroke-width="${s * 0.55}" stroke-linecap="round" stroke-linejoin="round"/>`;

  function awning() {
    let out = '';
    for (let i = 0; i < 8; i++) {
      const t0 = 126 + i * 33.5, t1 = t0 + 33.5, b0 = 104 + i * 39, b1 = b0 + 39;
      out += `<path d="M${t0} 114L${t1} 114L${b1} 176L${b0} 176Z" fill="${i % 2 ? C.w : C.g}" ${S}/>`;
    }
    return out;
  }

  function hero() {
    return `<svg viewBox="0 0 520 440" width="520" height="440" role="presentation" focusable="false">
      <path d="M92 214C70 120 150 44 262 44c118 0 196 70 190 170-6 96-82 168-190 168S112 310 92 214Z" fill="${C.tint}"/>
      <ellipse cx="262" cy="396" rx="190" ry="14" fill="${C.ink}" opacity=".10"/>
      ${plus(66, 118, 11)}${plus(468, 164, 9, C.gd)}${plus(446, 392, 8)}
      <circle cx="40" cy="250" r="5" fill="${C.y}" stroke="${C.ink}" stroke-width="2"/><circle cx="498" cy="318" r="6" fill="${C.g}"/><circle cx="108" cy="58" r="5" fill="${C.g}"/>

      <!-- shop -->
      <rect x="120" y="176" width="280" height="206" rx="10" fill="${C.w}" ${S}/>
      <rect x="196" y="60" width="128" height="46" rx="12" fill="${C.g}" ${S}/>
      <path d="M260 68v30M245 83h30" stroke="${C.w}" stroke-width="9" stroke-linecap="round"/>
      ${awning()}
      <rect x="146" y="198" width="132" height="140" rx="8" fill="${C.tint}" ${S}/>
      <path d="M146 250h132M146 300h132" ${S}/>
      <!-- shelf: bottles and boxes -->
      <rect x="158" y="214" width="22" height="36" rx="4" fill="${C.g}" ${S}/><rect x="163" y="206" width="12" height="9" rx="2" fill="${C.w}" ${S}/>
      <rect x="188" y="222" width="26" height="28" rx="4" fill="${C.w}" ${S}/><path d="M194 236h14" ${S}/>
      <rect x="222" y="212" width="20" height="38" rx="4" fill="${C.y}" ${S}/><rect x="226" y="204" width="12" height="9" rx="2" fill="${C.ink}"/>
      <rect x="248" y="226" width="22" height="24" rx="4" fill="${C.gd}" ${S}/>
      <rect x="160" y="262" width="34" height="38" rx="4" fill="${C.w}" ${S}/><path d="M168 276h18M168 286h10" ${S}/>
      <rect x="202" y="270" width="26" height="30" rx="4" fill="${C.g}" ${S}/><path d="M210 285h10" stroke="${C.w}" stroke-width="3" stroke-linecap="round"/>
      <rect x="236" y="262" width="34" height="38" rx="4" fill="${C.y}" ${S}/><path d="M244 276h18" ${S}/>
      ${capsule(180, 322, -12, C.g, C.w, 40, 18)}${capsule(238, 322, 10, C.y, C.w, 40, 18)}
      <!-- door -->
      <path d="M300 382V232a38 38 0 0 1 76 0v150Z" fill="${C.g}" ${S}/>
      <path d="M338 232v150" stroke="${C.ink}" stroke-width="3"/>
      <circle cx="326" cy="318" r="5" fill="${C.y}" stroke="${C.ink}" stroke-width="2"/><circle cx="350" cy="318" r="5" fill="${C.y}" stroke="${C.ink}" stroke-width="2"/>
      <path d="M338 246v26M325 259h26" stroke="${C.w}" stroke-width="7" stroke-linecap="round"/>
      <path d="M112 382h296" ${S}/>

      <!-- floating card: registration verdict -->
      <g transform="rotate(4 420 80)">
        <rect x="318" y="26" width="178" height="112" rx="16" fill="${C.w}" ${S}/>
        <rect x="334" y="42" width="84" height="8" rx="4" fill="${C.grey}"/>
        <rect x="334" y="58" width="112" height="28" rx="6" fill="${C.y}"/>
        <path d="M344 72h18M368 72h30" stroke="${C.ink}" stroke-width="6" stroke-linecap="round"/>
        <rect x="334" y="98" width="110" height="28" rx="14" fill="${C.g}"/>
        ${check(350, 111, 6, C.w)}<path d="M372 112h56" stroke="${C.w}" stroke-width="6" stroke-linecap="round"/>
      </g>
      <!-- floating card: nearby -->
      <g transform="rotate(-4 90 340)">
        <rect x="18" y="296" width="150" height="82" rx="16" fill="${C.w}" ${S}/>
        <path d="M54 352s-16-14-16-27a16 16 0 0 1 32 0c0 13-16 27-16 27Z" fill="${C.g}" ${S}/><circle cx="54" cy="325" r="5" fill="${C.w}"/>
        <path d="M86 322h62M86 338h40" stroke="${C.grey}" stroke-width="7" stroke-linecap="round"/>
      </g>
      <!-- floating card: assistant -->
      <g transform="rotate(5 440 320)">
        <path d="M388 278h96a14 14 0 0 1 14 14v34a14 14 0 0 1-14 14h-58l-22 18v-18h-16a14 14 0 0 1-14-14v-34a14 14 0 0 1 14-14Z" fill="${C.ink}" ${S}/>
        <circle cx="420" cy="309" r="6" fill="${C.w}"/><circle cx="440" cy="309" r="6" fill="${C.w}"/><circle cx="460" cy="309" r="6" fill="${C.y}"/>
      </g>
      ${capsule(70, 196, -32, C.g, C.w, 70, 28)}${capsule(452, 236, 28, C.y, C.g, 62, 24)}
    </svg>`;
  }

  /** A medicine carton with the NAFDAC number highlighted, and a magnifier. */
  function pack() {
    return `<svg viewBox="0 0 320 230" width="320" height="230" role="presentation" focusable="false">
      <ellipse cx="160" cy="210" rx="120" ry="10" fill="${C.ink}" opacity=".10"/>
      <path d="M52 52l20-24h196l20 24Z" fill="${C.mint}" ${S}/>
      <rect x="52" y="52" width="236" height="148" rx="6" fill="${C.w}" ${S}/>
      <rect x="52" y="52" width="236" height="26" fill="${C.g}" ${S}/>
      <path d="M72 66h60" stroke="${C.w}" stroke-width="6" stroke-linecap="round"/>
      ${plus(262, 65, 7, C.w)}
      <path d="M72 98h110M72 112h80" stroke="${C.grey}" stroke-width="8" stroke-linecap="round"/>
      <text x="72" y="144" font-family="Figtree, system-ui, sans-serif" font-size="12" fill="${C.ink}" opacity=".7">NAFDAC Reg. No:</text>
      <rect x="70" y="152" width="108" height="30" rx="4" fill="${C.y}"/>
      <text x="80" y="174" font-family="Familjen Grotesk, Trebuchet MS, sans-serif" font-weight="700" font-size="22" fill="${C.ink}" letter-spacing="1">A4-7559</text>
      <circle cx="236" cy="166" r="30" fill="${C.w}" fill-opacity=".85" ${S}/>
      <path d="M258 188l24 24" stroke="${C.ink}" stroke-width="9" stroke-linecap="round"/>
      ${check(226, 166, 7, C.g)}
    </svg>`;
  }

  function capsules() {
    return `<svg viewBox="0 0 240 170" width="240" height="170" role="presentation" focusable="false">
      ${capsule(80, 56, -28, C.y, C.w, 96, 36)}${capsule(158, 96, 24, C.w, C.g, 88, 34)}${capsule(76, 126, 8, C.g, C.w, 74, 28)}
      <circle cx="196" cy="34" r="16" fill="${C.w}" ${S}/><path d="M187 34h18" ${S}/>
      <circle cx="30" cy="94" r="12" fill="${C.y}" ${S}/>
      ${plus(210, 140, 9, C.w)}${plus(26, 28, 7, C.w)}
    </svg>`;
  }

  window.KemistArt = { hero, pack, capsules };
})();
